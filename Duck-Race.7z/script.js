/* Wheel of Names - Vanilla JS */
(function(){
  const qs = (sel, el=document) => el.querySelector(sel);
  const qsa = (sel, el=document) => Array.from(el.querySelectorAll(sel));

  // Elements
  const namesInput = qs('#namesInput');
  const namesCount = qs('#namesCount');
  const applyNamesBtn = qs('#applyNames');
  const shuffleNamesBtn = qs('#shuffleNames');
  const randomizeColorsBtn = qs('#randomizeColors');
  const spinBtn = qs('#spinBtn');
  const resetBtn = qs('#resetBtn');
  const canvas = qs('#wheelCanvas');
  const ctx = canvas.getContext('2d');
  const confettiCanvas = qs('#confettiCanvas');
  const resultsPanel = qs('#resultsPanel');
  const winnerAnnouncement = qs('#winnerAnnouncement');
  const spinAgainBtn = qs('#spinAgain');
  const closeResultsBtn = qs('#closeResults');
  const removeWinnerBtn = qs('#removeWinner');
  const spinBtnOverlay = qs('#spinBtnOverlay');
  const pointerEl = qs('.pointer');
  
  const toggleSettingsBtn = qs('#toggleSettings');
  const controlsPanel = qs('#controlsPanel');
  const appMain = qs('.app-main');
  const wheelSection = qs('.wheel-section');
  const selectionModeToggle = qs('#selectionModeToggle');
  const winnerModeRow = qs('#winnerModeRow');

  const modeRandom = qs('#modeRandom');
  const modeFixed = qs('#modeFixed');
  const fixedChoiceSel = qs('#fixedChoice');
  const modeLms = qs('#modeLms');
  const lmsProtectedSel = qs('#lmsProtected');
  const saveSelectionBtn = qs('#saveSelection');
  const spinDurationInput = qs('#spinDuration');
  const spinTurnsInput = qs('#spinTurns');

  // Sounds engine
  function createSoundEngine() {
    const AudioCtx = window.AudioContext || window.webkitAudioContext;
    let ctx;
    const ensure = () => { ctx = ctx || new AudioCtx(); return ctx; };

    function clickTick() {
      const ac = ensure();
      const o = ac.createOscillator();
      const g = ac.createGain();
      o.type = 'triangle';
      o.frequency.value = 880;
      g.gain.value = 0.0;
      o.connect(g).connect(ac.destination);
      const t = ac.currentTime;
      g.gain.setValueAtTime(0.0001, t);
      g.gain.exponentialRampToValueAtTime(0.05, t + 0.01);
      g.gain.exponentialRampToValueAtTime(0.0001, t + 0.05);
      o.start();
      o.stop(t + 0.06);
    }

    function fanfare() {
      const ac = ensure();
      const seq = [523, 659, 784, 1046];
      seq.forEach((f, i) => {
        const o = ac.createOscillator();
        const g = ac.createGain();
        o.type = 'sawtooth';
        o.frequency.value = f;
        g.gain.value = 0.0;
        o.connect(g).connect(ac.destination);
        const t = ac.currentTime + i*0.12;
        g.gain.setValueAtTime(0.0001, t);
        g.gain.exponentialRampToValueAtTime(0.08, t + 0.05);
        g.gain.exponentialRampToValueAtTime(0.0001, t + 0.25);
        o.start(t);
        o.stop(t + 0.27);
      });
    }

    return { clickTick, fanfare };
  }
  let muted = false;
  const sounds = createSoundEngine();

  // Confetti
  let confetti;
  function createConfetti() {
    const ctx2 = confettiCanvas.getContext('2d');
    let W, H;
    function resize() { W = confettiCanvas.width = confettiCanvas.offsetWidth; H = confettiCanvas.height = confettiCanvas.offsetHeight; }
    resize();
    const pieces = Array.from({length: 200}).map(() => ({
      x: Math.random()*W,
      y: -20 - Math.random()*H,
      r: 4 + Math.random()*5,
      c: `hsl(${Math.random()*360},85%,60%)`,
      s: 1 + Math.random()*2,
      a: Math.random()*Math.PI*2
    }));
    let raf;
    function draw() {
      ctx2.clearRect(0,0,W,H);
      pieces.forEach(p => {
        p.y += p.s;
        p.x += Math.sin(p.y/20)*0.8;
        p.a += 0.04;
        ctx2.save();
        ctx2.translate(p.x, p.y);
        ctx2.rotate(p.a);
        ctx2.fillStyle = p.c;
        ctx2.fillRect(-p.r/2, -p.r/2, p.r, p.r);
        ctx2.restore();
      });
      raf = requestAnimationFrame(draw);
    }
    confetti = { stop() { cancelAnimationFrame(raf); ctx2.clearRect(0,0,W,H); }, start: () => { draw(); } };
    return confetti;
  }

  // Wheel state
  let entries = [];
  let colors = [];
  let angle = 0; // radians
  let spinning = false;
  let lastTickSector = -1;

  function parseNames(text) {
    return text.split(/\r?\n/).map(s => s.trim()).filter(Boolean);
  }

  function randomColor(i) {
    const hue = (i * 360 / Math.max(6, entries.length)) % 360;
    return `hsl(${hue}, 80%, 55%)`;
  }

  function randomizeColors() {
    colors = entries.map((_, i) => `hsl(${Math.random()*360}, 80%, 55%)`);
  }

  function applyNames() {
    entries = parseNames(namesInput.value);
    if (entries.length === 0) entries = ['—'];
    if (colors.length !== entries.length) {
      colors = entries.map((_, i) => randomColor(i));
    }
    populateFixedSelect();
    drawWheel();
    if (namesCount) namesCount.textContent = String(entries.length);
    // After repopulating selects, restore selection if saved
    restoreSelection();
  }

  function shuffleArray(a){ for(let i=a.length-1;i>0;i--){ const j=Math.floor(Math.random()*(i+1)); [a[i],a[j]]=[a[j],a[i]]; } return a; }

  function populateFixedSelect() {
    fixedChoiceSel.innerHTML = '';
    lmsProtectedSel.innerHTML = '';
    entries.forEach((name, i) => {
      const opt = document.createElement('option');
      opt.value = String(i);
      opt.textContent = name;
      fixedChoiceSel.appendChild(opt);
      const opt2 = document.createElement('option');
      opt2.value = String(i);
      opt2.textContent = name;
      lmsProtectedSel.appendChild(opt2);
    });
    fixedChoiceSel.disabled = !modeFixed.checked;
    lmsProtectedSel.disabled = !modeLms.checked;
  }

  function syncCanvasSize() {
    const dpr = window.devicePixelRatio || 1;
    const rect = canvas.getBoundingClientRect();
    const size = Math.min(rect.width, rect.height);
    const px = Math.floor(size * dpr);
    if (canvas.width !== px || canvas.height !== px) {
      canvas.width = px;
      canvas.height = px;
    }
  }

  function drawWheel() {
    syncCanvasSize();
    const W = canvas.width, H = canvas.height; const cx = W/2, cy = H/2; const r = Math.min(W, H)/2 - Math.max(8, W*0.01);
    ctx.clearRect(0,0,W,H);

    const n = entries.length;
    if (n === 0) return;
    const arc = (Math.PI * 2) / n;

    // pointer alignment with canvas padding
    try {
      const stage = canvas.parentElement;
      const padTop = parseFloat(getComputedStyle(stage).paddingTop) || 0;
      pointerEl.style.top = `${padTop}px`;
    } catch {}

    // draw slices
    for (let i=0; i<n; i++) {
      const start = angle + i*arc;
      const end = start + arc;
      // slice
      ctx.beginPath();
      ctx.moveTo(cx, cy);
      ctx.arc(cx, cy, r, start, end);
      ctx.closePath();
      ctx.fillStyle = colors[i % colors.length] || randomColor(i);
      ctx.fill();
      ctx.strokeStyle = 'rgba(255,255,255,.15)';
      ctx.lineWidth = n > 16 ? 1 : 2;
      ctx.stroke();

      // text: vertical stack along the slice radius
      const mid = start + arc/2;
      const inner = r * 0.22;
      const outer = r * 0.9;
      const widthRadius = (inner + outer) / 2;
      const allowedWidth = 2 * Math.sin(arc/2) * widthRadius * 0.9;

      let fontSize = Math.min(26, Math.max(10, Math.floor(r * 0.11)));
      ctx.font = `bold ${fontSize}px system-ui, -apple-system, Segoe UI, Roboto, Helvetica, Arial`;
      let maxCharWidth = ctx.measureText('W').width;
      while (maxCharWidth > allowedWidth && fontSize > 10) {
        fontSize -= 1;
        ctx.font = `bold ${fontSize}px system-ui, -apple-system, Segoe UI, Roboto, Helvetica, Arial`;
        maxCharWidth = ctx.measureText('W').width;
      }

      const spacing = Math.ceil(fontSize * 1.05);
      const availableRadial = outer - inner;
      let chars = Array.from(entries[i]);
      while (chars.length * spacing > availableRadial && fontSize > 10) {
        fontSize -= 1;
        ctx.font = `bold ${fontSize}px system-ui, -apple-system, Segoe UI, Roboto, Helvetica, Arial`;
      }
      // truncate with ellipsis if still too tall
      while (chars.length * spacing > availableRadial && chars.length > 1) {
        chars.pop();
        if (chars.length > 0) chars[chars.length - 1] = '…';
      }

      ctx.fillStyle = '#fff';
      ctx.textAlign = 'center';
      ctx.textBaseline = 'middle';
      for (let ci = 0; ci < chars.length; ci++) {
        const radiusPos = outer - (ci * spacing) - spacing * 0.5;
        const x = cx + Math.cos(mid) * radiusPos;
        const y = cy + Math.sin(mid) * radiusPos;
        ctx.fillText(chars[ci], x, y);
      }
    }

    // center cap
    ctx.beginPath();
    ctx.arc(cx, cy, r*0.08, 0, Math.PI*2);
    ctx.fillStyle = '#fff';
    ctx.fill();
    ctx.strokeStyle = 'rgba(0,0,0,.25)';
    ctx.stroke();
  }

  function sectorAtPointer() {
    const n = entries.length;
    const arc = (Math.PI*2)/n;
    const pointerAngle = -Math.PI/2; // top, arrow points downward on canvas
    // normalize sector index so that angle 0 is at +x; adjust offset
    let a = (pointerAngle - angle) % (Math.PI*2);
    if (a < 0) a += Math.PI*2;
    const idx = Math.floor(a / arc);
    return ((idx % n) + n) % n;
  }

  function spinTo(targetIndex) {
    const n = entries.length;
    const arc = (Math.PI*2)/n;
    const pointerAngle = -Math.PI/2; // must match sectorAtPointer
    const currentAtPointer = sectorAtPointer();

    const duration = Math.max(3, Math.min(12, parseFloat(spinDurationInput.value) || 6));
    const spins = Math.max(3, Math.min(12, parseInt(spinTurnsInput.value, 10) || 7));

    // Compute target angle so that the selected slice lands under the pointer.
    // Add a small random jitter so it doesn't always stop at the exact center of the slice.
    const targetAngleForIndex = (idx) => {
      const center = pointerAngle - (idx + 0.5) * arc;
      const jitter = (Math.random() - 0.5) * (arc * 0.84); // stay within +/- 42% of slice width
      return center + jitter;
    };

    // Add full spins forward to ensure nice rotation
    const currentAngle = angle;
    let finalAngle = targetAngleForIndex(targetIndex);
    // ensure finalAngle is forward by adding multiples of 2PI
    while (finalAngle <= currentAngle) finalAngle += Math.PI*2;
    finalAngle += spins * (Math.PI*2);

    const startTime = performance.now();
    const startAngle = angle;
    spinning = true; lastTickSector = -1;

    function easeOutCubic(t) { return 1 - Math.pow(1-t, 3); }

    function step(ts) {
      const t = Math.min(1, (ts - startTime) / (duration * 1000));
      const eased = easeOutCubic(t);
      angle = startAngle + (finalAngle - startAngle) * eased;
      drawWheel();

      // tick sound when crossing sector boundary
      const currentSector = sectorAtPointer();
      if (currentSector !== lastTickSector) {
        lastTickSector = currentSector;
        if (!muted) sounds.clickTick();
      }

      if (t < 1) {
        requestAnimationFrame(step);
      } else {
        spinning = false;
        onFinish(targetIndex);
      }
    }

    requestAnimationFrame(step);
  }

  function onFinish(index) {
    const name = entries[index] || '—';
    winnerAnnouncement.textContent = `Winner: ${name}`;
    resultsPanel.classList.remove('hidden');
    if (resetBtn) resetBtn.disabled = false;
    // Hide spin controls once the game starts and on finish
    spinBtn.classList.add('hidden');
    spinBtnOverlay.classList.add('hidden');
    // Move focus to dialog primary action for accessibility
    try { spinAgainBtn.focus({ preventScroll: true }); } catch {}
    try { if (!muted) sounds.fanfare(); } catch {}

    if (!confetti) createConfetti();
    confetti.start();

    // Last Man Standing: require user to remove the picked player until stop threshold
    if (modeLms.checked) {
      const stopAt = parseInt(lmsStopAt.value, 10) || 1;
      if (entries.length > stopAt) {
        spinAgainBtn.disabled = true;
        try { removeWinnerBtn.focus({ preventScroll: true }); } catch {}
      } else {
        // Already at stop threshold — treat as final
        spinAgainBtn.disabled = true;
        removeWinnerBtn.disabled = true;
      }
    }
  }

  // Actions
  applyNamesBtn.addEventListener('click', () => { applyNames(); });
  namesInput.addEventListener('input', () => { applyNames(); });
  shuffleNamesBtn.addEventListener('click', () => {
    const list = parseNames(namesInput.value);
    shuffleArray(list);
    namesInput.value = list.join('\n');
    applyNames();
  });
  randomizeColorsBtn.addEventListener('click', () => { randomizeColors(); drawWheel(); });
  spinBtnOverlay.addEventListener('click', () => spinBtn.click());

  // Toggle Selection Mode visibility in settings (button inside settings footer)
  selectionModeToggle && selectionModeToggle.addEventListener('click', () => {
    const hidden = winnerModeRow.classList.toggle('collapsible-hidden');
    selectionModeToggle.textContent = hidden ? 'Show Selection Mode' : 'Hide Selection Mode';
    selectionModeToggle.setAttribute('aria-expanded', String(!hidden));
    // Ensure settings panel is visible so the toggle has context
    if (controlsPanel.classList.contains('hidden')) {
      controlsPanel.classList.remove('hidden');
      appMain.classList.remove('full-width');
      wheelSection.classList.add('hidden');
      wheelSection.setAttribute('aria-hidden', 'true');
      toggleSettingsBtn.textContent = 'Hide Settings';
      toggleSettingsBtn.setAttribute('aria-expanded', 'true');
    }
  });

  function syncModeUI() {
    fixedChoiceSel.disabled = !modeFixed.checked;
    lmsProtectedSel.disabled = !modeLms.checked;
    // Drop any auto-protected state when switching modes
    if (!modeLms.checked) delete window.__lmsProtectedIndex;
  }
  modeRandom.addEventListener('change', syncModeUI);
  modeFixed.addEventListener('change', syncModeUI);
  modeLms.addEventListener('change', syncModeUI);

  // Persist selection mode and pick
  function persistSelection() {
    const mode = modeFixed.checked ? 'fixed' : (modeLms.checked ? 'lms' : 'random');
    const fixedName = fixedChoiceSel.selectedOptions?.[0]?.textContent || null;
    const lmsName = lmsProtectedSel.selectedOptions?.[0]?.textContent || null;
    const payload = { mode, fixedName, lmsName };
    try { localStorage.setItem('selectionMode', JSON.stringify(payload)); } catch {}
  }
  function restoreSelection() {
    try {
      const raw = localStorage.getItem('selectionMode');
      if (!raw) return;
      const { mode, fixedName, lmsName } = JSON.parse(raw);
      if (mode === 'fixed') modeFixed.checked = true; else if (mode === 'lms') modeLms.checked = true; else modeRandom.checked = true;
      syncModeUI();
      // Set selected options by matching text content
      if (fixedName) {
        Array.from(fixedChoiceSel.options).forEach((opt) => { if (opt.textContent === fixedName) fixedChoiceSel.value = opt.value; });
      }
      if (lmsName) {
        Array.from(lmsProtectedSel.options).forEach((opt) => { if (opt.textContent === lmsName) lmsProtectedSel.value = opt.value; });
      }
    } catch {}
  }
  saveSelectionBtn && saveSelectionBtn.addEventListener('click', () => {
    persistSelection();
    // brief visual feedback by flashing the button
    saveSelectionBtn.disabled = true;
    setTimeout(() => { saveSelectionBtn.disabled = false; }, 500);
  });

  spinBtn.addEventListener('click', () => {
    if (spinning) return;
    resultsPanel.classList.add('hidden');
    if (confetti) confetti.stop();
    if (resetBtn) resetBtn.disabled = true;
    // Hide spin buttons during the spin
    spinBtn.classList.add('hidden');
    spinBtnOverlay.classList.add('hidden');

    let targetIndex;
    if (modeFixed.checked) {
      targetIndex = parseInt(fixedChoiceSel.value, 10) || 0;
    } else if (modeLms.checked) {
      // Last Man Standing: avoid the selected protected name
      const avoidIdx = parseInt(lmsProtectedSel.value, 10);
      const validAvoid = Number.isFinite(avoidIdx) ? avoidIdx : -1;
      if (entries.length <= 1) {
        targetIndex = 0;
      } else {
        do {
          targetIndex = Math.floor(Math.random()*entries.length);
        } while (targetIndex === validAvoid);
      }
    } else {
      targetIndex = Math.floor(Math.random()*entries.length);
    }
    spinTo(targetIndex);
  });

  // Proceed button removed

  spinAgainBtn.addEventListener('click', () => {
    resultsPanel.classList.add('hidden');
    if (confetti) confetti.stop();
    spinBtn.click();
  });

  // Close winner dialog
  function closeResults() {
    resultsPanel.classList.add('hidden');
    if (confetti) confetti.stop();
    spinBtn.classList.remove('hidden');
    spinBtnOverlay.classList.remove('hidden');
    try { (spinBtnOverlay.offsetParent ? spinBtnOverlay : spinBtn).focus({ preventScroll: true }); } catch {}
  }
  closeResultsBtn.addEventListener('click', closeResults);

  // Remove winner: delete selected winner from entries and names input, then allow next spin
  removeWinnerBtn.addEventListener('click', () => {
    const currentWinner = winnerAnnouncement.textContent.replace(/^Winner:\s*/, '');
    const list = parseNames(namesInput.value);
    const idx = list.findIndex(n => n === currentWinner);
    if (idx !== -1) {
      list.splice(idx, 1);
      namesInput.value = list.join('\n');
      applyNames();
    }
    // Always close and prepare for next spin
    resultsPanel.classList.add('hidden');
    if (confetti) confetti.stop();
    // Allow next spin
    spinBtn.classList.remove('hidden');
    spinBtnOverlay.classList.remove('hidden');
    spinAgainBtn.disabled = false;
    removeWinnerBtn.disabled = false;
    try { (spinBtnOverlay.offsetParent ? spinBtnOverlay : spinBtn).focus({ preventScroll: true }); } catch {}
  });

  // Last Man Standing mode helpers
  function removeNameByIndex(idx) {
    const list = parseNames(namesInput.value);
    if (idx >= 0 && idx < list.length) {
      list.splice(idx, 1);
      namesInput.value = list.join('\n');
      applyNames();
    }
  }

  // After finish, if LMS has no protected index yet, set it to the first picked name
  // Remove earlier auto-protect behavior; LMS relies solely on the selected dropdown value now

  // Keyboard shortcuts for better UX (ignore while typing in inputs/textarea)
  window.addEventListener('keydown', (e) => {
    const tag = (e.target && e.target.tagName || '').toLowerCase();
    const isEditing = tag === 'input' || tag === 'textarea' || tag === 'select' || e.isComposing;
    if (isEditing) return;
    const k = (e.key || '').toLowerCase();
    if (k === ' ' || k === 'enter') {
      // If dialog open and Enter pressed → Spin Again
      if (!resultsPanel.classList.contains('hidden') && k === 'enter') {
        e.preventDefault();
        spinAgainBtn.click();
        return;
      }
      // If not spinning and dialog closed → start spin
      if (!spinning && resultsPanel.classList.contains('hidden')) {
        e.preventDefault();
        spinBtn.click();
      }
    }
    if (k === 'escape' && !resultsPanel.classList.contains('hidden')) closeResults();
  });

  

  // Populate fixed select initially
  function initFromText() {
    applyNames();
    restoreSelection();
  }

  // Resize confetti canvas on window resize
  window.addEventListener('resize', () => {
    drawWheel();
    if (confetti) { confetti.stop(); confetti.start(); }
  });

  // Settings toggle: when settings are visible, hide the wheel entirely
  toggleSettingsBtn.addEventListener('click', () => {
    const settingsHidden = controlsPanel.classList.toggle('hidden');
    if (!settingsHidden) {
      // Show settings only
      appMain.classList.add('full-width');
      wheelSection.classList.add('hidden');
      wheelSection.setAttribute('aria-hidden', 'true');
      // Hide Spin button from settings area
      spinBtn.classList.add('hidden');
    } else {
      // Hide settings, show wheel
      appMain.classList.add('full-width');
      wheelSection.classList.remove('hidden');
      wheelSection.removeAttribute('aria-hidden');
      // Restore Spin button visibility when settings are hidden
      spinBtn.classList.remove('hidden');
      // redraw wheel to adapt to space
      drawWheel();
    }
    toggleSettingsBtn.textContent = settingsHidden ? 'Show Settings' : 'Hide Settings';
    toggleSettingsBtn.setAttribute('aria-expanded', String(!settingsHidden));
  });

  initFromText();
  syncModeUI();
  drawWheel();
})();
