Place your assets in this folder.

Required filenames used by the app:
- whistle.mp3  (start sound)
- cheer.mp3    (finish sound)

Optional:
- You can put your custom duck images here and select them per duck in the UI. Supports PNG/JPG/SVG.

Note: The app includes a vector duck rendered in code when no image is chosen, so a default image file is not required.
